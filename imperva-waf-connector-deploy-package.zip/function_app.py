"""
function_app.py

Timer-triggered poller for Imperva WAF Cloud logs -> Microsoft Sentinel,
via the Logs Ingestion API. Python v2 programming model (decorator-based,
no function.json needed).

Flow:
  1. Validation      - Config() validates all required env vars.
  2. Reconciliation  - list the index file, diff against the stored
                        checkpoint, log how many files are pending.
  3. Build and Get   - download + decompress + CEF-parse each pending
                        file (capped by MAX_FILES_PER_RUN per run).
  4. Replace fields  - Attack Name / Attack Severity / Device Version ->
                        underscore names; anything outside the known
                        53-column schema bucketed into AdditionalDetails.
  5. Ingest          - push the full batch to Sentinel via the DCR.
  6. Checkpoint      - advanced ONLY after a successful ingest, and only
                        as far as the last file actually processed this
                        run. (The legacy implementation wrote the
                        checkpoint before downloading/ingesting anything
                        -- a failed run could silently lose files. Fixed
                        here.)
  7. Debug summary   - one structured log line with counts + timing.

Unlike Boomi/IDCS, this connector keeps file-based checkpointing rather
than stateless window polling -- Imperva's index-file model has no
natural time window, so dedup has to be checkpoint-based.
"""

import logging
import datetime

import azure.functions as func

from config import Config
from state_manager import StateManager
from imperva_client import ImpervaClient
from transform import transform_records
from ingest import SentinelIngestor

app = func.FunctionApp()


@app.function_name(name="ImpervaWAFLogPoller")
@app.timer_trigger(
    schedule="0 */10 * * * *",
    arg_name="mytimer",
    run_on_startup=False,
    use_monitor=True,
)
def imperva_waf_log_poller(mytimer: func.TimerRequest) -> None:
    run_start = datetime.datetime.now(datetime.UTC)

    if mytimer.past_due:
        logging.warning("Timer trigger is running past due.")

    # --- Step 1: Validation ---
    try:
        config = Config()
    except ValueError:
        logging.exception("Configuration error — check Function App Application Settings.")
        raise

    state_manager = StateManager(config.storage_connection_string)
    client = ImpervaClient(config, state_manager)

    # --- Step 2: Reconciliation ---
    try:
        all_files = client.list_index_file()
    except Exception:
        logging.exception("Failed to download logs.index from Imperva — failing run.")
        raise

    pending = client.pending_files(all_files)
    if len(pending) > config.max_files_per_run:
        logging.info(
            "%d file(s) pending, capping this run to %d (MAX_FILES_PER_RUN).",
            len(pending), config.max_files_per_run,
        )
        pending = pending[: config.max_files_per_run]

    if not pending:
        logging.info(
            "RUN SUMMARY | no pending files | completed_at=%s",
            run_start.strftime("%Y-%m-%dT%H:%M:%SZ"),
        )
        return

    # --- Step 3: Build and Get ---
    raw_records = []
    last_successfully_downloaded = None
    for file_name in pending:
        logging.info("Downloading file %s", file_name)
        try:
            raw_records.extend(client.download_and_parse(file_name))
            last_successfully_downloaded = file_name
        except Exception:
            logging.exception(
                "Failed to download/parse %s — stopping this run here; "
                "checkpoint will only advance up to the last good file.",
                file_name,
            )
            break

    if last_successfully_downloaded is None:
        logging.error("No files could be downloaded/parsed this run — failing.")
        raise RuntimeError("Imperva download/parse failed for all pending files.")

    # --- Step 4: Replace fields ---
    transformed_records = transform_records(raw_records)

    # --- Step 5: Ingest ---
    ingestor = SentinelIngestor(config)
    try:
        sent_count = ingestor.send(transformed_records)
    except Exception:
        logging.exception("Failed to ingest records into Sentinel — checkpoint will NOT advance.")
        raise

    # --- Step 6: Checkpoint (only after a successful ingest) ---
    if not config.dry_run:
        state_manager.post(last_successfully_downloaded)
    else:
        logging.info(
            "[DRY RUN] Checkpoint NOT advanced (would have moved to %s).",
            last_successfully_downloaded,
        )

    # --- Step 7: Debug summary ---
    files_processed = pending.index(last_successfully_downloaded) + 1
    run_end = datetime.datetime.now(datetime.UTC)
    duration_seconds = (run_end - run_start).total_seconds()
    logging.info(
        "RUN SUMMARY | files_processed=%d/%d | fetched=%d | ingested=%d "
        "| checkpoint=%s | duration=%.2fs | completed_at=%s",
        files_processed, len(pending), len(raw_records), sent_count,
        last_successfully_downloaded, duration_seconds,
        run_end.strftime("%Y-%m-%dT%H:%M:%SZ"),
    )
