"""
imperva_client.py

Downloads Imperva WAF Cloud (Incapsula) log files from the Log Server
API and parses CEF-formatted lines into raw event dicts.

Keeps the original download/decompress/CEF-parsing approach (it works),
with three deliberate changes from the legacy implementation:

  1. The "file marked encrypted but no decryption logic exists" case now
     fails loudly with a clear NotImplementedError instead of an opaque
     NameError several lines later.
  2. pending_files() no longer writes the checkpoint itself -- it only
     reads it. function_app.py commits the checkpoint (via
     StateManager.post) only after a successful ingest, so a failed run
     can't "lose" files.
  3. The old cs1-cs9 label-collapsing rename logic has been removed
     entirely. Every field -- including *Label fields -- is passed
     through raw and unmodified. Field renaming/whitelisting now happens
     downstream in transform.py, against the full 53-column schema.
"""

import re
import zlib
import logging

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import urllib3

logger = logging.getLogger("imperva_client")


class ImpervaClient:
    def __init__(self, config, state_manager):
        self.config = config
        self.state_manager = state_manager
        self.url = config.log_server_uri

        retries = Retry(
            total=3,
            status_forcelist={500, 429},
            backoff_factor=1,
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retries)
        self.session = requests.Session()
        self.session.mount("https://", adapter)
        self.auth_headers = urllib3.make_headers(
            basic_auth=f"{config.imperva_api_id}:{config.imperva_api_key}"
        )

    def list_index_file(self):
        r = self.session.get(f"{self.url}/logs.index", headers=self.auth_headers)
        r.raise_for_status()
        files = [line.decode("utf-8") for line in r.iter_lines() if line]
        logger.info("Index file lists %d file(s) total.", len(files))
        return files

    def pending_files(self, all_files):
        """Returns files not yet processed, per the stored checkpoint.
        Read-only -- does not write the checkpoint."""
        last_file = self.state_manager.get()
        if last_file is None:
            logger.info("No checkpoint found -- treating all %d file(s) as pending.", len(all_files))
            return list(all_files)
        try:
            idx = all_files.index(last_file)
            pending = all_files[idx + 1:]
        except ValueError:
            logger.warning(
                "Checkpoint file '%s' not found in current index (likely rotated out of "
                "the retention window) -- processing all %d file(s) currently listed.",
                last_file, len(all_files),
            )
            pending = list(all_files)
        logger.info("%d file(s) pending.", len(pending))
        return pending

    def download_and_parse(self, file_name):
        r = self.session.get(f"{self.url}/{file_name}", stream=True, headers=self.auth_headers)
        r.raise_for_status()
        return self._decrypt_and_unpack(file_name, r.content)

    def _decrypt_and_unpack(self, file_name, file_content):
        file_header, file_data = file_content.split(b"|==|\n", 1)
        file_header = file_header.decode("utf-8")

        if "key:" in file_header:
            raise NotImplementedError(
                f"File {file_name} is marked encrypted ('key:' present in header) "
                f"but decryption is not implemented in this client. Check your "
                f"Imperva log integration settings -- if encryption is intentionally "
                f"enabled, this client needs decryption logic added before it can "
                f"process files."
            )

        try:
            events_data = zlib.decompressobj().decompress(file_data).decode("utf-8")
        except zlib.error:
            events_data = file_data.decode("utf-8")

        events = []
        for line in events_data.splitlines():
            if "CEF" in line:
                events.append(self._parse_cef(line))
        logger.info("Parsed %d event(s) from %s.", len(events), file_name)
        return events

    @staticmethod
    def _parse_cef(cef_raw):
        rx = r'([^=\s\|]+)?=((?:[\\]=|[^=])+)(?:\s|$)'
        parsed = {"EventVendor": "Imperva", "EventProduct": "Incapsula", "EventType": "SIEMintegration"}
        header_array = cef_raw.split('|')
        parsed["Device Version"] = header_array[3]
        parsed["Signature"] = header_array[4]
        parsed["Attack Name"] = header_array[5]
        parsed["Attack Severity"] = header_array[6]
        for key, val in re.findall(rx, cef_raw):
            if val.startswith('"') and val.endswith('"'):
                val = val[1:-1]
            parsed[key] = val
        return parsed
