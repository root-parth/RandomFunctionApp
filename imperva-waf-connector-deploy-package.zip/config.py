"""
config.py

Reads and validates all environment variables the Imperva WAF connector
needs. Fails loudly (ValueError) at startup if anything required is
missing -- same pattern as the Boomi and Oracle IDCS connectors.
"""

import os


class Config:
    def __init__(self):
        # --- Imperva WAF Log Server settings ---
        self.imperva_api_id = self._require("ImpervaAPIID")
        self.imperva_api_key = self._require("ImpervaAPIKey")
        self.log_server_uri = self._require("ImpervaLogServerURI").rstrip("/")

        # --- Checkpoint storage (reuses the Function App's own storage
        # account -- Azure Table Storage, no extra resource needed) ---
        self.storage_connection_string = self._require("AzureWebJobsStorage")

        # --- Safety cap: max NEW files processed in a single run, so a
        # long backlog (e.g. after downtime) doesn't blow past function
        # timeout or Sentinel payload limits in one go ---
        self.max_files_per_run = int(os.environ.get("MAX_FILES_PER_RUN", "50"))

        # --- Sentinel / Logs Ingestion API settings ---
        self.dry_run = os.environ.get("DRY_RUN", "false").strip().lower() == "true"
        self.dce_endpoint = self._require("DCE_ENDPOINT") if not self.dry_run else os.environ.get("DCE_ENDPOINT", "")
        self.dcr_immutable_id = self._require("DCR_IMMUTABLE_ID") if not self.dry_run else os.environ.get("DCR_IMMUTABLE_ID", "")
        # Must match the stream name declared in your DCR.json
        self.dcr_stream_name = os.environ.get("DCR_STREAM_NAME", "Custom-ImpervaWAFStream")

    @staticmethod
    def _require(name: str) -> str:
        val = os.environ.get(name)
        if val is None or not val.strip():
            raise ValueError(
                f"Required environment variable '{name}' is missing or empty. "
                f"Set it in Function App Application Settings."
            )
        return val.strip()
