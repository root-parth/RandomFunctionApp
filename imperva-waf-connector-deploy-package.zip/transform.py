"""
transform.py

1. Renames the three space-containing raw CEF fields to their
   underscore equivalents, matching the exact column names in the
   53-column production schema:
       "Attack Name"     -> "Attack_Name"
       "Attack Severity" -> "Attack_Severity"
       "Device Version"  -> "Device_Version"

   NOTE: your written instructions described the target as "AttackName"
   / "AttackSeverity" (no underscore, no space), but the schema JSON you
   pasted lists "Attack_Name" / "Attack_Severity" / "Device_Version"
   (underscore). This code follows the schema JSON, since that's what
   the DCR stream declaration and table will actually enforce -- flip
   FIELD_RENAMES below if you actually want the no-underscore form.

2. Splits every renamed record into the known columns (passed through
   completely unchanged, including *Label fields -- no collapsing) plus
   an AdditionalDetails (dynamic) bucket for anything not in that list,
   so new/unexpected fields are never silently dropped.

3. Computes TimeGenerated (datetime) from the raw 'start' epoch-ms
   field. 'start' itself is left untouched as its own raw string column,
   per the schema -- TimeGenerated is a new, additional column.
"""

import datetime
import logging

logger = logging.getLogger("transform")

FIELD_RENAMES = {
    "Attack Name": "Attack_Name",
    "Attack Severity": "Attack_Severity",
    "Device Version": "Device_Version",
}

# The confirmed columns, excluding TimeGenerated (computed below) and
# AdditionalDetails (the overflow bucket). Includes cs1-cs15 and their
# *Label pairs as dedicated columns -- not just the ones seen in the
# initial sample, since cs1-cs8 are known to appear in some traffic even
# though they weren't in the captured sample.
KNOWN_COLUMNS = {
    "cs1", "cs1Label", "cs2", "cs2Label", "cs3", "cs3Label", "cs4", "cs4Label",
    "cs5", "cs5Label", "cs6", "cs6Label", "cs7", "cs7Label", "cs8", "cs8Label",
    "cs9", "cs9Label", "cs10", "cs10Label", "cs12", "cs12Label", "cs15", "cs15Label",
    "Rulename", "postbody", "cicode", "qstr", "cn1", "sip", "spt", "in", "xff",
    "EventVendor", "EventProduct", "EventType", "Device_Version", "Signature",
    "Attack_Name", "Attack_Severity", "fileId", "sourceServiceName", "siteid",
    "suid", "requestClientApplication", "deviceFacility", "dproc", "ccode",
    "Customer", "start", "request", "requestMethod", "app", "act",
    "deviceExternalId", "cpt", "src", "ver", "end", "fileType", "filePermission",
    "CapSupport", "JavascriptSupport", "COSupport", "VID_g",
    "clappsig", "clapp", "latitude", "longitude", "ref",
}


def _compute_time_generated(record):
    start = record.get("start")
    if not start:
        return None
    try:
        return datetime.datetime.utcfromtimestamp(int(start) / 1000.0).isoformat() + "Z"
    except (ValueError, TypeError):
        logger.warning("Could not parse 'start' value %r into a timestamp.", start)
        return None


def transform_record(record):
    renamed = dict(record)
    for old_key, new_key in FIELD_RENAMES.items():
        if old_key in renamed:
            renamed[new_key] = renamed.pop(old_key)

    out = {}
    extra = {}
    for key, value in renamed.items():
        if key in KNOWN_COLUMNS:
            out[key] = value
        else:
            extra[key] = value

    time_generated = _compute_time_generated(out)
    if time_generated:
        out["TimeGenerated"] = time_generated

    if extra:
        out["AdditionalDetails"] = extra

    return out


def transform_records(records):
    transformed = [transform_record(r) for r in records]
    overflow_count = sum(1 for r in transformed if "AdditionalDetails" in r)
    if overflow_count:
        logger.warning(
            "%d of %d record(s) had fields outside the known-columns schema "
            "-- routed to AdditionalDetails. Review these to see if the schema needs updating.",
            overflow_count, len(transformed),
        )
    return transformed
