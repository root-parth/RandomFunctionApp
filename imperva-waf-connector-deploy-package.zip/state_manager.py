"""
state_manager.py

Tracks the last Imperva log file successfully processed, using Azure
Table Storage in the same storage account already provisioned for the
Functions runtime (AzureWebJobsStorage) -- no extra resource needed,
unlike the old implementation which used a dedicated Azure File Share.

IMPORTANT BEHAVIOR CHANGE from the old StateManager: this one does NOT
decide when to advance the checkpoint -- it just stores/returns a value.
function_app.py is responsible for calling post() only after a batch has
been successfully ingested into Sentinel. The old code called it as soon
as the index file was read, before anything was downloaded or ingested,
which meant a failed run could still silently "consume" files it never
actually sent anywhere.
"""

import logging

from azure.data.tables import TableClient
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError

logger = logging.getLogger("state_manager")

TABLE_NAME = "impervachekpoint"
PARTITION_KEY = "imperva"
ROW_KEY = "last_processed_file"


class StateManager:
    def __init__(self, connection_string: str):
        self.table_client = TableClient.from_connection_string(
            connection_string, table_name=TABLE_NAME
        )
        try:
            self.table_client.create_table()
        except ResourceExistsError:
            pass

    def get(self):
        """Returns the last processed file name, or None if no checkpoint exists yet."""
        try:
            entity = self.table_client.get_entity(PARTITION_KEY, ROW_KEY)
            return entity.get("LastFile")
        except ResourceNotFoundError:
            return None
        except Exception:
            logger.exception("Failed to read checkpoint -- treating as no checkpoint.")
            return None

    def post(self, file_name: str) -> None:
        """Advances the checkpoint. Call this ONLY after a successful ingest."""
        entity = {
            "PartitionKey": PARTITION_KEY,
            "RowKey": ROW_KEY,
            "LastFile": file_name,
        }
        self.table_client.upsert_entity(entity)
        logger.info("Checkpoint advanced to: %s", file_name)
