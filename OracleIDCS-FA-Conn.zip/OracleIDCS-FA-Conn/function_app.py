"""
function_app.py

Timer-triggered poller for Oracle IDCS AuditEvents -> Microsoft Sentinel,
via the Logs Ingestion API.

Flow:
  1. Validation      - Config() validates all required env vars.
  2. Reconciliation  - Log the polling window for visibility.
  3. Build and Get   - Fetch a fresh OAuth2 token, query AuditEvents,
                        follow opc-next-page pagination.
  4. Ingest          - Push the raw batch to Sentinel via the DCR - no
                        transform step needed.
  5. Debug summary   - One structured log line with counts + timing.

No checkpointing: fixed sliding window (now - QUERY_WINDOW_MINUTES -> now),
same design as the Boomi connector.
"""

import logging
import datetime

import azure.functions as func

from config import Config
from oidcs_client import OidcsClient
from ingest import SentinelIngestor

app = func.FunctionApp()


@app.function_name(name="OracleIdcsAuditLogPoller")
@app.timer_trigger(
    schedule="0 */10 * * * *",   # every 10 minutes - keep in sync with QUERY_WINDOW_MINUTES
    arg_name="mytimer",
    run_on_startup=False,
    use_monitor=True,
)
def oracle_idcs_audit_log_poller(mytimer: func.TimerRequest) -> None:
    run_start = datetime.datetime.now(datetime.UTC)

    if mytimer.past_due:
        logging.warning("Timer trigger is running past due.")

    # --- Step 1: Validation ---
    try:
        config = Config()
    except ValueError:
        logging.exception("Configuration error - check Function App Application Settings.")
        raise

    # --- Step 2: Reconciliation ---
    end_time = run_start.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    start_time = (
        run_start - datetime.timedelta(minutes=config.query_window_minutes)
    ).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    logging.info(
        "Polling window: %s -> %s (%d minute window)",
        start_time, end_time, config.query_window_minutes,
    )

    # --- Step 3: Build and Get ---
    client = OidcsClient(config)
    try:
        raw_records = client.fetch_all(start_time, end_time)
    except Exception:
        logging.exception("Failed to fetch records from IDCS AuditEvents API - failing run.")
        raise  # fail loudly; no partial-success state to preserve

    # --- Step 4: Ingest (no transform - DCR handles id -> LogId via KQL) ---
    ingestor = SentinelIngestor(config)
    try:
        sent_count = ingestor.send(raw_records)
    except Exception:
        logging.exception("Failed to ingest records into Sentinel - failing run.")
        raise

    # --- Step 5: Debug summary ---
    run_end = datetime.datetime.now(datetime.UTC)
    duration_seconds = (run_end - run_start).total_seconds()
    logging.info(
        "RUN SUMMARY | window=[%s -> %s] | fetched=%d | ingested=%d "
        "| duration=%.2fs | completed_at=%s",
        start_time, end_time, len(raw_records), sent_count, duration_seconds,
        run_end.strftime("%Y-%m-%dT%H:%M:%SZ"),
    )
