"""
config.py

Reads and validates all environment variables the IDCS connector needs.
"""

import os


class Config:
    def __init__(self):
        # --- IDCS OAuth2 + API settings ---
        self.tenant_url = self._require("OIDCS_TENANT_URL").rstrip("/")
        self.client_id = self._require("OIDCS_CLIENT_ID")
        self.client_secret = self._require("OIDCS_CLIENT_SECRET")

        # --- Polling window ---
        self.query_window_minutes = int(os.environ.get("QUERY_WINDOW_MINUTES", "10"))

        # --- Pagination ---
        self.page_size = int(os.environ.get("PAGE_SIZE", "1000"))
        self.max_pagination_pages = int(os.environ.get("MAX_PAGINATION_PAGES", "20"))

        # --- Sentinel / Logs Ingestion API settings ---
        self.dry_run = os.environ.get("DRY_RUN", "false").strip().lower() == "true"
        self.dce_endpoint = self._require("DCE_ENDPOINT") if not self.dry_run else os.environ.get("DCE_ENDPOINT", "")
        self.dcr_immutable_id = self._require("DCR_IMMUTABLE_ID") if not self.dry_run else os.environ.get("DCR_IMMUTABLE_ID", "")
        # Matches the stream name declared in your DCR.json
        self.dcr_stream_name = os.environ.get("DCR_STREAM_NAME", "Custom-OracleIDCSStream")

    @staticmethod
    def _require(name: str) -> str:
        val = os.environ.get(name)
        if val is None or not val.strip():
            raise ValueError(
                f"Required environment variable '{name}' is missing or empty. "
                f"Set it in Function App Application Settings."
            )
        return val.strip()
