"""
oidcs_client.py

Handles talking to Oracle IDCS's AuditEvents API:
  1. Fetch an OAuth2 client-credentials token (fresh every run - simplest
     option given the connector only runs every ~10 min, well under any
     token expiry window).
  2. Query AuditEvents for the polling window.
  3. Follow pagination using the 'opc-next-page' RESPONSE HEADER - this is
     the authoritative signal for "more pages exist," not a count/math
     formula. totalResults is only used to log an expected-page-count
     estimate and to size the safety cap.
"""

import base64
import logging
import math

import requests

logger = logging.getLogger("oidcs_client")


class OidcsClient:
    def __init__(self, config):
        self.config = config
        self.session = requests.Session()
        self.token_url = f"{config.tenant_url}/oauth2/v1/token"
        self.audit_events_url = f"{config.tenant_url}/admin/v1/AuditEvents"

    def _get_token(self) -> str:
        creds = base64.b64encode(
            f"{self.config.client_id}:{self.config.client_secret}".encode()
        ).decode()

        resp = self.session.post(
            self.token_url,
            headers={
                "Authorization": f"Basic {creds}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            data={
                "grant_type": "client_credentials",
                "scope": "urn:opc:idm:__myscopes__",
            },
            timeout=30,
        )
        self._raise_with_context(resp, "token fetch")
        return resp.json()["access_token"]

    def fetch_all(self, start_time: str, end_time: str) -> list:
        """Fetches every AuditEvents record in the window, following
        opc-next-page pagination. Returns the full list of raw records."""
        token = self._get_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/scim+json",
        }

        filter_query = f'timestamp gt "{start_time}" and timestamp lt "{end_time}"'
        params = {"filter": filter_query, "count": self.config.page_size}

        all_records = []
        page_num = 1
        next_page_token = None
        total_results = None
        safety_cap = self.config.max_pagination_pages

        logger.info("Querying IDCS AuditEvents | window=%s to %s | page_size=%d",
                    start_time, end_time, self.config.page_size)

        while True:
            request_params = {"page": next_page_token} if next_page_token else params

            resp = self.session.get(
                self.audit_events_url, headers=headers, params=request_params, timeout=60
            )
            self._raise_with_context(resp, f"page {page_num}")
            data = resp.json()

            if total_results is None:
                total_results = data.get("totalResults", 0)
                estimated_pages = math.ceil(total_results / self.config.page_size) if total_results else 0
                logger.info(
                    "totalResults=%d | estimated_pages=%d | safety_cap=%d",
                    total_results, estimated_pages, safety_cap,
                )

            records = data.get("Resources", []) or []
            all_records.extend(records)
            logger.info("Page %d: %d record(s) received", page_num, len(records))

            # This header is the real signal, not a computed page count.
            next_page_token = resp.headers.get("opc-next-page")
            if not next_page_token:
                break

            page_num += 1
            if page_num > safety_cap:
                logger.warning(
                    "Hit MAX_PAGINATION_PAGES=%d safety cap - stopping early. "
                    "totalResults=%d suggested ~%d pages; investigate if this recurs.",
                    safety_cap, total_results, estimated_pages,
                )
                break

        logger.info(
            "Fetch complete | total_records=%d | pages_fetched=%d | totalResults_reported=%s",
            len(all_records), page_num, total_results,
        )
        return all_records

    @staticmethod
    def _raise_with_context(resp: requests.Response, context: str) -> None:
        """Same pattern as boomi_client.py - raise with full diagnostic
        detail instead of a bare error, so failures are actually debuggable."""
        try:
            resp.raise_for_status()
        except requests.HTTPError:
            logger.error(
                "IDCS API error during %s | status=%s | content-type=%s | body(first 500 chars)=%r",
                context, resp.status_code, resp.headers.get("Content-Type"), resp.text[:500],
            )
            raise
