import datetime
import requests
import logging
import os
import json
import hashlib
import hmac
import base64
import azure.functions as func
import re

# Configuration - get from environment variables
sentinel_customer_id = os.environ.get('WorkspaceID')
sentinel_shared_key = os.environ.get('WorkspaceKey')
sentinel_log_type = 'ParthOnWebhook'  # Changed for testing
logging.info("Sentinel Logtype:{}".format(sentinel_log_type))
logAnalyticsUri = os.environ.get('LogAnaltyicsUri')

# Set default Log Analytics URI if not provided
if ((logAnalyticsUri in (None, '') or str(logAnalyticsUri).isspace())):    
    logAnalyticsUri = 'https://' + str(sentinel_customer_id) + '.ods.opinsights.azure.com'

logging.info("Log Analytics URI: {}".format(logAnalyticsUri))
logging.info("Sentinel Log Type: {}".format(sentinel_log_type))

# Validate Log Analytics URI format
pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern, str(logAnalyticsUri))
if(not match):
    raise Exception("TestWebhook: Invalid Log Analytics Uri.")

# Main function - Azure Functions entry point
def main(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    logging.info('Info: Current retry count: {}'.format(context.retry_context.retry_count))   
    logging.info('Info: Test webhook data connector started')  
    logging.info("Sentinel Logtype: {}".format(sentinel_log_type))  

    # Get the incoming request data
    try:
        req_body = req.get_json()
        if req_body is None:
            logging.warning("No JSON body found in request")
            req_body = {}
        
        # Add some metadata for testing
        req_body["webhook_received_at"] = datetime.datetime.utcnow().isoformat()
        req_body["function_name"] = "test_webhook_function"
        
        # Add any headers that might be useful for testing
        if req.headers:
            req_body["request_headers"] = dict(req.headers)
        
        # Process the JSON data
        body = json.dumps(customizeJson(json.dumps(req_body)))
        logging.info("Info: Converted input json to dict and further to json")
        logging.info("Request body: {}".format(body))
        
    except Exception as e:
        logging.error("Error processing request body: {}".format(str(e)))
        return func.HttpResponse(
            "Error processing request body: {}".format(str(e)),
            status_code=400
        )
    
    # Try to send data to Sentinel
    try:
        post_data(sentinel_customer_id, sentinel_shared_key, body, sentinel_log_type)
        logging.info("Info: Test webhook data connector execution completed successfully.")
        return func.HttpResponse(
            "Test webhook data connector execution completed successfully.",
            status_code=200
        )      
    except Exception as err:
        logging.error("Something wrong. Exception error text: {}".format(err))
        logging.error("Error: Test webhook data connector execution failed with an internal server error.")
        return func.HttpResponse(
            "Internal server error: {}".format(str(err)),
            status_code=500
        )

#####################
######Functions######
#####################

# Process JSON data - simplified for testing
def customizeJson(inputJson):
    required_fields_data = {}    
    newJson_dict = json.loads(inputJson)    
    
    for key, value in newJson_dict.items():
        if isinstance(value, dict):
            # Convert nested objects to formatted JSON strings
            required_fields_data[key] = json.dumps(value, indent=4)
        elif isinstance(value, list):
            # Convert lists to JSON strings too
            required_fields_data[key] = json.dumps(value, indent=4)
        else:
            # Keep simple values as-is
            required_fields_data[key] = value
    
    return required_fields_data  

# Build the API signature for Azure Log Analytics
def build_signature(customer_id, shared_key, date, content_length, method, content_type, resource):
    x_headers = 'x-ms-date:' + date
    string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
    bytes_to_hash = bytes(string_to_hash, encoding="utf-8")  
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = "SharedKey {}:{}".format(customer_id, encoded_hash)
    return authorization

# Send data to Azure Log Analytics
def post_data(customer_id, shared_key, body, log_type):
    method = 'POST'
    content_type = 'application/json'
    resource = '/api/logs'
    currentdate = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    content_length = len(body)
    signature = build_signature(customer_id, shared_key, currentdate, content_length, method, content_type, resource)
    uri = 'https://' + customer_id + '.ods.opinsights.azure.com' + resource + '?api-version=2016-04-01'
    
    headers = {
        'content-type': content_type,
        'Authorization': signature,
        'Log-Type': log_type,
        'x-ms-date': currentdate
    }

    logging.info("Sending data to: {}".format(uri))
    logging.info("Headers: {}".format(headers))
    
    response = requests.post(uri, data=body, headers=headers)
    
    if (response.status_code >= 200 and response.status_code <= 299):
        logging.info('Info: Event was successfully sent to Azure Log Analytics')
        print('Info: Event was successfully sent to Azure Log Analytics')
    elif (response.status_code == 401):
        logging.error("The authentication credentials are incorrect or missing. Error code: {}".format(response.status_code))
        raise Exception("Authentication failed with Azure Log Analytics")
    else:
        logging.error("Failed to send data. Response code: {}".format(response.status_code))
        logging.error("Response body: {}".format(response.text))
        raise Exception("Failed to send data to Azure Log Analytics. Status code: {}".format(response.status_code))