import os
import asyncio
from azure.storage.blob.aio import ContainerClient
import json
import logging
import azure.functions as func
import re
import gzip
import io
import time
import aiohttp
from json import JSONDecodeError
import traceback

from .sentinel_connector_async import AzureSentinelConnectorAsync

logging.getLogger(
    'azure.core.pipeline.policies.http_logging_policy').setLevel(logging.ERROR)
logging.getLogger('charset_normalizer').setLevel(logging.ERROR)

# Azure Storage and Sentinel Configuration
AZURE_STORAGE_CONNECTION_STRING = os.environ['AZURE_STORAGE_CONNECTION_STRING']
CONTAINER_NAME = os.environ['CONTAINER_NAME']
WORKSPACE_ID = os.environ['WORKSPACE_ID']
SHARED_KEY = os.environ['SHARED_KEY']
LOG_TYPE = 'RadwareSecurityLogs'
LINE_SEPARATOR = os.environ.get(
    'lineSeparator', '[\n\r\x0b\v\x0c\f\x1c\x1d\x85\x1e\u2028\u2029]+')

# Concurrency and Processing Configs
MAX_CONCURRENT_PROCESSING_FILES = int(os.environ.get('MAX_CONCURRENT_PROCESSING_FILES', 10))
MAX_PAGE_SIZE = int(MAX_CONCURRENT_PROCESSING_FILES * 20)
MAX_BUCKET_SIZE = int(os.environ.get('MAX_BUCKET_SIZE', 2000))
MAX_CHUNK_SIZE_MB = int(os.environ.get('MAX_CHUNK_SIZE_MB', 1))
MAX_SCRIPT_EXEC_TIME_MINUTES = 5

LOG_ANALYTICS_URI = os.environ.get('logAnalyticsUri')

if not LOG_ANALYTICS_URI or str(LOG_ANALYTICS_URI).isspace():
    LOG_ANALYTICS_URI = f'https://{WORKSPACE_ID}.ods.opinsights.azure.com'

pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern, str(LOG_ANALYTICS_URI))
if not match:
    raise Exception("Invalid Log Analytics URI.")


async def main(mytimer: func.TimerRequest):
    try:
        logging.info('Starting script')
        logging.info(f'Concurrency parameters: MAX_CONCURRENT_PROCESSING_FILES {MAX_CONCURRENT_PROCESSING_FILES}, MAX_PAGE_SIZE {MAX_PAGE_SIZE}, MAX_BUCKET_SIZE {MAX_BUCKET_SIZE}.')
        
        conn = AzureBlobStorageConnector(AZURE_STORAGE_CONNECTION_STRING, CONTAINER_NAME, MAX_CONCURRENT_PROCESSING_FILES)
        container_client = conn._create_container_client()
        
        async with container_client:
            async with aiohttp.ClientSession() as session:
                cors = []
                async for blob in conn.get_blobs():
                    try:
                        cor = conn.process_blob(blob, container_client, session)
                        cors.append(cor)
                    except Exception as e:
                        logging.error(f'Exception in processing blob {blob["name"]}: {e}')
                    
                    if len(cors) >= MAX_PAGE_SIZE:
                        await asyncio.gather(*cors)
                        cors = []
                    
                    if conn.check_if_script_runs_too_long():
                        logging.info('Script is running too long. Stopping new blob processing.')
                        break

                if cors:
                    await asyncio.gather(*cors)
                    logging.info(f'Processed {conn.total_blobs} files with {conn.total_events} events.')

        logging.info(f'Script finished. Processed files: {conn.total_blobs}. Processed events: {conn.total_events}')
    except Exception as ex:
        logging.error(f'An error occurred in the main script: {str(ex)}')
        logging.error(traceback.format_exc())


class AzureBlobStorageConnector:
    def __init__(self, conn_string, container_name, max_concurrent_processing_files=10):
        self.__conn_string = conn_string
        self.__container_name = container_name
        self.semaphore = asyncio.Semaphore(max_concurrent_processing_files)
        self.script_start_time = int(time.time())
        self.total_blobs = 0
        self.total_events = 0   

    def _create_container_client(self):
        try:
            return ContainerClient.from_connection_string(
                self.__conn_string, self.__container_name, logging_enable=False, 
                max_single_get_size=MAX_CHUNK_SIZE_MB * 1024 * 1024, 
                max_chunk_get_size=MAX_CHUNK_SIZE_MB * 1024 * 1024
            )
        except Exception as ex:
            logging.error(f'Error in _create_container_client: {str(ex)}')
            logging.error(traceback.format_exc())
            return None        
        
    async def get_blobs(self):
        try:
            container_client = self._create_container_client()
            logging.info("Fetching blobs from storage")
            async with container_client:
                async for blob in container_client.list_blobs():
                    if 'ownership-challenge' not in blob['name']:
                        yield blob
        except Exception as ex:
            logging.error(f'Error in get_blobs: {ex}')
            logging.error(traceback.format_exc())

    def check_if_script_runs_too_long(self):
        now = int(time.time())
        duration = now - self.script_start_time
        max_duration = int(MAX_SCRIPT_EXEC_TIME_MINUTES * 60 * 0.85)
        return duration > max_duration

    async def delete_blob(self, blob, container_client):
        try:
            logging.info(f"Deleting blob {blob['name']}")
            await container_client.delete_blob(blob['name'])
        except Exception as ex:
            logging.error(f'Error while deleting blob {blob["name"]}: {ex}')
            logging.error(traceback.format_exc())

    async def process_blob(self, blob, container_client, session: aiohttp.ClientSession):
        try:
            async with self.semaphore:
                logging.info(f"Processing {blob['name']}")
                
                sentinel = AzureSentinelConnectorAsync(session, LOG_ANALYTICS_URI, WORKSPACE_ID, SHARED_KEY, LOG_TYPE, queue_size=MAX_BUCKET_SIZE)
                blob_cor = await container_client.download_blob(blob['name'])
                blob_bytes = await blob_cor.readall()

                # Validate if the file is a valid GZ file
                if not blob_bytes.startswith(b'\x1f\x8b'):
                    logging.error(f'Error: {blob["name"]} is not a valid GZ file.')
                    return

                try:
                    with gzip.GzipFile(fileobj=io.BytesIO(blob_bytes), mode='rb') as gz_file:
                        blob_data = gz_file.read().decode('utf-8')
                except Exception as e:
                    logging.error(f'Error decompressing GZ file {blob["name"]}: {e}')
                    return

                try:
                    data = json.loads(blob_data)
                    if not isinstance(data, list):
                        logging.error(f'Error: JSON content in {blob["name"]} is not an array.')
                        return
                except JSONDecodeError:
                    logging.error(f'Error: Invalid JSON format in {blob["name"]}')
                    return

                for event in data:
                    await sentinel.send(event)

                await sentinel.flush()
                await self.delete_blob(blob, container_client)

                self.total_blobs += 1
                self.total_events += sentinel.successfull_sent_events_number

                logging.info(f"Finished processing {blob['name']}. Sent events: {sentinel.successfull_sent_events_number}")
                
        except Exception as ex:
            logging.error(f"Error in process_blob: {ex}")
            logging.error(traceback.format_exc())
