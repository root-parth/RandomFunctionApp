"""
Pure Python event-mapping logic for the Delinea -> Sentinel webhook.

Deliberately has ZERO Azure SDK dependencies so it can be:
  - imported by function_app.py when running in Azure, and
  - imported by local_dev_server.py when dry-running locally with Postman/curl

If you change the DCR's stream schema, update _map_event_to_record() here and
both the Azure path and the local test path stay in sync automatically.
"""

import json
from datetime import datetime, timezone

# Keys under which an inbound payload might nest a list of events, in case
# Delinea (or any upstream caller) wraps multiple events in an envelope
# instead of posting a bare JSON array.
ARRAY_ENVELOPE_KEYS = ("events", "Events", "records", "Records", "data", "Data")


def normalize_events(body) -> list:
    """Accept a single event object or an array of event objects (optionally
    wrapped in a known envelope key) and always return a flat list."""
    if isinstance(body, list):
        return body

    if isinstance(body, dict):
        for key in ARRAY_ENVELOPE_KEYS:
            value = body.get(key)
            if isinstance(value, list):
                return value
        # Single event posted as a bare object.
        return [body]

    raise ValueError("Request body must be a JSON object or a JSON array of objects")


def map_event_to_record(evt: dict) -> dict:
    """Map one Delinea event onto the Custom-DelineaPlatformEvents_CL schema.

    Update this function if/when you push a different schema into the DCR -
    it's the single source of truth for the field mapping, used both locally
    and in Azure.
    """
    details = evt.get("details") or {}
    timestamp = details.get("timestamp")

    return {
        "TimeGenerated": timestamp or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "RawData": json.dumps(evt, default=str),
        "EventType": evt.get("event_type"),
        "Service": evt.get("service"),
        "Level": evt.get("level"),
        "User": details.get("user"),
        "SecretId": details.get("secret_id"),
    }
