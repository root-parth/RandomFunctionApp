"""
Delinea PAM -> Microsoft Sentinel ingestion webhook.

Replaces the Delinea-provided Logic App with an Azure Function (Python,
Linux Consumption plan) that:
  1. Accepts one event OR an array of events via HTTP POST (webhook).
  2. Maps each event onto the Custom-DelineaPlatformEvents_CL stream schema.
  3. Authenticates to the Log Ingestion API using the Function App's
     system-assigned managed identity (no secrets/keys involved).
  4. Uploads the batch to the Data Collection Rule (DCR) via the
     Data Collection Endpoint (DCE), which forwards it into the custom
     table in the Sentinel-connected Log Analytics workspace.

Required app settings (populated automatically by the ARM template):
  DCE_ENDPOINT      - the "logs ingestion" endpoint of the DCE,
                      e.g. https://delinea-sentinel-dce-xxxx.<region>-1.ingest.monitor.azure.com
  DCR_IMMUTABLE_ID  - the DCR's immutableId (NOT the DCR resource name)
  DCR_STREAM_NAME   - defaults to "Custom-DelineaPlatformEvents_CL"
"""

import json
import logging
import os

import azure.functions as func
from azure.core.exceptions import HttpResponseError
from azure.identity import ManagedIdentityCredential
from azure.monitor.ingestion import LogsIngestionClient

from event_mapper import map_event_to_record, normalize_events

app = func.FunctionApp()

# --- configuration -----------------------------------------------------

DCE_ENDPOINT = os.environ.get("DCE_ENDPOINT")
DCR_IMMUTABLE_ID = os.environ.get("DCR_IMMUTABLE_ID")
STREAM_NAME = os.environ.get("DCR_STREAM_NAME", "Custom-DelineaPlatformEvents_CL")

# The managed identity credential is resolved lazily on first use so that
# importing this module (e.g. for local testing) doesn't require Azure
# credentials to be available. See _get_client() below.
_client = None


def _get_client() -> LogsIngestionClient:
    global _client
    if _client is None:
        if not DCE_ENDPOINT or not DCR_IMMUTABLE_ID:
            raise RuntimeError(
                "DCE_ENDPOINT and DCR_IMMUTABLE_ID app settings must be configured."
            )
        credential = ManagedIdentityCredential()
        _client = LogsIngestionClient(endpoint=DCE_ENDPOINT, credential=credential)
    return _client


# --- HTTP trigger ----------------------------------------------------------

@app.function_name(name="DelineaIngest")
@app.route(route="ingest", methods=["POST"], auth_level=func.AuthLevel.FUNCTION)
def delinea_ingest(req: func.HttpRequest) -> func.HttpResponse:
    try:
        raw_body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            json.dumps({"status": "error", "message": "Request body is not valid JSON"}),
            status_code=400,
            mimetype="application/json",
        )

    try:
        events = normalize_events(raw_body)
    except ValueError as exc:
        return func.HttpResponse(
            json.dumps({"status": "error", "message": str(exc)}),
            status_code=400,
            mimetype="application/json",
        )

    if not events:
        return func.HttpResponse(
            json.dumps({"status": "error", "message": "No events found in request body"}),
            status_code=400,
            mimetype="application/json",
        )

    records = [map_event_to_record(evt) for evt in events]

    try:
        client = _get_client()
        # LogsIngestionClient.upload() internally handles the Log Ingestion
        # API's payload-size and gzip requirements, chunking as needed, so a
        # single call here is sufficient even for large batches.
        client.upload(rule_id=DCR_IMMUTABLE_ID, stream_name=STREAM_NAME, logs=records)
    except HttpResponseError as exc:
        logging.error("Log Ingestion API rejected the batch: %s", exc)
        return func.HttpResponse(
            json.dumps(
                {
                    "status": "error",
                    "message": "Failed to ingest events into Sentinel",
                    "detail": str(exc),
                }
            ),
            status_code=502,
            mimetype="application/json",
        )
    except RuntimeError as exc:
        logging.error("Configuration error: %s", exc)
        return func.HttpResponse(
            json.dumps({"status": "error", "message": str(exc)}),
            status_code=500,
            mimetype="application/json",
        )

    logging.info("Ingested %d event(s) into stream %s", len(records), STREAM_NAME)
    return func.HttpResponse(
        json.dumps({"status": "success", "ingested": len(records)}),
        status_code=200,
        mimetype="application/json",
    )
